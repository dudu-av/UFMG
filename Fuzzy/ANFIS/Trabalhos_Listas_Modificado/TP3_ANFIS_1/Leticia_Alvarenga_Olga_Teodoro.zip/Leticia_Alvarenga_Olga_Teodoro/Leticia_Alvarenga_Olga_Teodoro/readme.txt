##### Parte 2 - Python

Relatório incluído no arquivo em python
Para a execução do código da questão 2, caso queira utilizar o colab, faça os seguintes passos:

1 - Abra um novo arquivo no colab (https://colab.research.google.com/notebooks/intro.ipynb?utm_source=scs-index#recent=true), selecione
	a opção de upload de arquivos e busque o arquivo Leticia_Alvarenga_Olga_Teodoro.ipynb
2 - Após isso, vá em "arquivos" (no símbolo ao lado esquerdo) e adicione todos os arquivos da biblioteca
	https://github.com/jfpower/anfis-pytorch (exceto cluste_data, fileio, gitignore, readme e license)
3 - E, por fim, vá em "Ambiente de execução" e selecione "Executar tudo"

##### Parte 3 - Matlab